val = 0.0



def change():
    global val
    val = 1.0
    print("val is " + str(val))