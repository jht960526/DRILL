from globals import *

change()
print("val is " + str(val))